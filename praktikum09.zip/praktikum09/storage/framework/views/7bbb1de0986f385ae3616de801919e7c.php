<?php
    $nama = $nama = 'Muhammad Zidan';
        echo 'Apa kabar ' . $nama . ' ?';
?><?php /**PATH C:\xampp\htdocs\PeraktikumWeb2\praktikum09\resources\views/Kondisi.blade.php ENDPATH**/ ?>