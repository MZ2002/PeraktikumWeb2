<?php
$nama = 'Muhammad Zidan';
$nilai = 90.99;
?>

<?php if($nilai >= 70): ?>
    <?php $ket = "Lulus"; ?>
<?php else: ?>
    <?php $ket = "Gagal"; ?>
<?php endif; ?>

siswa dinyatakan <?php echo e($nama); ?> dinyatakan <?php echo e($ket); ?><?php /**PATH C:\xampp\htdocs\PeraktikumWeb2\praktikum09\resources\views/nilai.blade.php ENDPATH**/ ?>