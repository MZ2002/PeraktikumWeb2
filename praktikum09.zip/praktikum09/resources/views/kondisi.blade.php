@php
    $nama = $nama = 'Muhammad Zidan';
        echo 'Apa kabar ' . $nama . ' ?';
@endphp